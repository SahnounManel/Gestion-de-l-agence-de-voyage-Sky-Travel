#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct  
{
	char nomhotel[100];
	char etoile[100];
	char prixswe[100];
	char prixa1[100];
	char prixa2[100];
	char prixa3[100];
	char prixper[100];
}hotel;

void ajouter_hotel(hotel C);



void afficher_hotel(GtkWidget *liste);




void info(char nbrper[100],char nbradu[100],char nbrswe[100],char nbra1[100],char nbra2[100],char nbra3[100],char datea[100],char datel[100],char id[100]);




hotel search(char f[100]);



void search2(char hjk[]);

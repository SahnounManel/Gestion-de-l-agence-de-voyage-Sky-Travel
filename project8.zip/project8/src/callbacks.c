#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "hotel.h"




void
on_fbutton38_clicked			(GtkWidget	*button,
					gpointer	user_data)
{
	GtkWidget *input;
	GtkWidget *fenetre_info;
	char nbrper[100],nbradu[100],nbrswe[100],nbra1[100],nbra2[100],nbra3[100],datea[100],datel[100],id[100];
	
	fenetre_info = lookup_widget(button,"fenetre_info");	
	
	input = lookup_widget(button,"fentry15");
	strcpy(nbrper,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry16");
	strcpy(nbradu,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry17");
	strcpy(nbrswe,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry18");
	strcpy(nbra1,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry19");
	strcpy(nbra2,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry20");
	strcpy(nbra3,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry21");
	strcpy(datea,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry22");
	strcpy(datel,gtk_entry_get_text(GTK_ENTRY(input)));
	input = lookup_widget(button,"fentry23");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	info(nbrper,nbradu,nbrswe,nbra1,nbra2,nbra3,datea,datel,id);
}

void
on_fbutton23_clicked			(GtkWidget	*button,
					gpointer	user_data)
{
	GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
	GtkWidget *adding_hotels;
	
	hotel h;
	
	adding_hotels = lookup_widget(button,"adding_hotels");
	
	input1 = lookup_widget(button,"fentry12");
	strcpy(h.nomhotel,gtk_entry_get_text(GTK_ENTRY(input1)));
	input2 = lookup_widget(button,"fentry6");
	strcpy(h.etoile,gtk_entry_get_text(GTK_ENTRY(input2)));
	input3 = lookup_widget(button,"fentry7");
	strcpy(h.prixswe,gtk_entry_get_text(GTK_ENTRY(input3)));
	input4 = lookup_widget(button,"fentry8");
	strcpy(h.prixa1,gtk_entry_get_text(GTK_ENTRY(input4)));
	input5 = lookup_widget(button,"fentry9");
	strcpy(h.prixa2,gtk_entry_get_text(GTK_ENTRY(input5)));
	input6 = lookup_widget(button,"fentry10");
	strcpy(h.prixa3,gtk_entry_get_text(GTK_ENTRY(input6)));
	input7 = lookup_widget(button,"fentry11");
	strcpy(h.prixper,gtk_entry_get_text(GTK_ENTRY(input7)));
	ajouter_hotel(h);
}











void
on_fretour_clicked                      (GtkWidget	*button,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout, *fenetre_afficher;
	fenetre_afficher = lookup_widget(button,"fenetre_afficher");

	gtk_widget_destroy(fenetre_afficher);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);
}


void
on_fretour2_clicked                      (GtkWidget	*button,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout2, *fenetre_afficher2;
	fenetre_afficher2 = lookup_widget(button,"fenetre_afficher2");

	gtk_widget_destroy(fenetre_afficher2);
	fenetre_ajout2=create_fenetre_ajout2();
	gtk_widget_show(fenetre_ajout2);
}


void
on_fafficher_clicked                    (GtkWidget	*button,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout;
	GtkWidget *fenetre_afficher;
	GtkWidget *treeview1;

	fenetre_ajout=lookup_widget(button,"fenetre_ajout");
	
	//gtk_widget_destroy(fenetre_ajout);
	fenetre_afficher=lookup_widget(button,"fenetre_ajout");
	fenetre_afficher=create_fenetre_afficher();

	gtk_widget_show(fenetre_afficher);

	treeview1=lookup_widget(fenetre_afficher,"treeview1");
	
	afficher_hotel(treeview1);
}




void
on_fafficher2_clicked                    (GtkWidget	*button,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout2;
	GtkWidget *fenetre_afficher2;
	GtkWidget *treeview2;

	fenetre_ajout2=lookup_widget(button,"fenetre_ajout2");
	
	//gtk_widget_destroy(fenetre_ajout2);
	fenetre_afficher2=lookup_widget(button,"fenetre_afficher2");
	fenetre_afficher2=create_fenetre_afficher2();

	gtk_widget_show(fenetre_afficher2);

	treeview2=lookup_widget(fenetre_afficher2,"treeview2");
	
	afficher_hotel(treeview2);
}




void
on_frecherche_clicked                    (GtkWidget	*button,
                                        gpointer         user_data)
{
	GtkWidget *input;
	char f[100];
	hotel h;
	input = lookup_widget(button,"fentry170");
	strcpy(f,gtk_entry_get_text(GTK_ENTRY(input)));
	search(f);
	

	GtkWidget *fenetre_ajout;
	GtkWidget *fenetre_info;

	fenetre_ajout=lookup_widget(button,"fenetre_ajout");

	//gtk_widget_destroy(fenetre_ajout);
	fenetre_info=lookup_widget(button,"fenetre_info");
	fenetre_info=create_fenetre_info();
	
	gtk_widget_show(fenetre_info);
	
}




void
on_frecherche2_clicked                    (GtkWidget	*button,
                                        gpointer         user_data)
{
	GtkWidget *input;
	char f[100];
	hotel h;
	input = lookup_widget(button,"fentry180");
	strcpy(f,gtk_entry_get_text(GTK_ENTRY(input)));
	search2(f);
	

	GtkWidget *fenetre_ajout2;
	GtkWidget *adding_hotels;

	fenetre_ajout2=lookup_widget(button,"fenetre_ajout2");

	//gtk_widget_destroy(fenetre_ajout2);
	adding_hotels=lookup_widget(button,"adding_hotels");
	adding_hotels=create_adding_hotels();
	
	gtk_widget_show(adding_hotels);
	
}














void
on_fbutton41_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
	GtkWidget *admin_edit;
	GtkWidget *adding_hotels;

	admin_edit=lookup_widget(button,"admin_edit");

	//gtk_widget_destroy(admin_edit);
	adding_hotels=lookup_widget(button,"adding_hotels");
	adding_hotels=create_adding_hotels();
	
	gtk_widget_show(adding_hotels);
}


void
on_fbutton10_clicked			(GtkWidget	*button,
					gpointer	user_data)
{
	GtkWidget *admin_edit;
	GtkWidget *fenetre_ajout2;

	admin_edit=lookup_widget(button,"admin_edit");

	//gtk_widget_destroy(admin_edit);
	fenetre_ajout2=lookup_widget(button,"fenetre_ajout2");
	fenetre_ajout2=create_fenetre_ajout2();
	
	gtk_widget_show(fenetre_ajout2);
}






void
on_fbutton11_clicked			(GtkWidget *button,
					gpointer	user_data)
{
	GtkWidget *admin_edit;
	GtkWidget *fenetre_ajout;

	admin_edit=lookup_widget(button,"admin_edit");

	//gtk_widget_destroy(admin_edit);
	fenetre_ajout=lookup_widget(button,"fenetre_ajout");
	fenetre_ajout=create_fenetre_ajout();
	
	gtk_widget_show(fenetre_ajout);	
}







#include <gtk/gtk.h>
#include <stdlib.h>


void
on_fbutton38_clicked			(GtkWidget	*button,
					gpointer	user_data);



void
on_fbutton23_clicked			(GtkWidget	*button,
					gpointer	user_data);




void
on_fretour_clicked                      (GtkWidget	*button,
                                        gpointer         user_data);






void
on_fretour2_clicked                      (GtkWidget	*button,
                                        gpointer         user_data);



void
on_fafficher_clicked                    (GtkWidget	*button,
                                        gpointer         user_data);






void
on_fafficher2_clicked                    (GtkWidget	*button,
                                        gpointer         user_data);




void
on_frecherche_clicked                    (GtkWidget	*button,
                                        gpointer         user_data);












void
on_frecherche2_clicked                    (GtkWidget	*button,
                                        gpointer         user_data);





void
on_fbutton41_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);







void
on_fbutton11_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_fbutton10_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

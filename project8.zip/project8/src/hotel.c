#include "hotel.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>





enum
{
	NOMHOTEL,
	ETOILE,
	PRIXSWE,
	PRIXA1,
	PRIXA2,
	PRIXA3,
	PRIXPER,
	COLUMNS
};


/*void ajouter_hotel(hotel h)
{
	FILE *f=NULL;
	f=fopen("hotel.txt","a+");
	if(f!=NULL)
	{
		fprintf(f,"%s %s %s %s %s %s %s \n", 	h.nomhotel,h.etoile,h.prixswe,h.prixa1,h.prixa2,h.prixa3,h.prixper);
		fclose(f);
	}
}
*/


void ajouter_hotel(hotel C)
{
FILE* f=NULL;
f=fopen("hotel.txt", "a+");
if (f!=NULL)
{fprintf(f,"%s %s %s %s %s %s %s \n", C.nomhotel,C.etoile,C.prixswe,C.prixa1,C.prixa2,C.prixa3,C.prixper);
fclose(f);}
}


void afficher_hotel(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nomhotel[100];
	char etoile[100];
	char prixswe[100];
	char prixa1[100];
	char prixa2[100];
	char prixa3[100];
	char prixper[100];

	FILE *f;
	
	store = gtk_tree_view_get_model(liste);
	if (store == NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nomhotel",renderer,"text",NOMHOTEL,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("etoile",renderer,"text",ETOILE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("priswe",renderer,"text",PRIXSWE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

				renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prixa1",renderer,"text",PRIXA1,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prixa2",renderer,"text",PRIXA2,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prixa3",renderer,"text",PRIXA3,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prixper",renderer,"text",PRIXPER,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


		f = fopen("hotel.txt","r");
		if(f==NULL)
		{
			return;
		}

		else
		{
			f =fopen("hotel.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s \n",nomhotel,etoile,prixswe,prixa1,prixa2,prixa3,prixper)!=EOF)
				{
					gtk_list_store_append(store,&iter);

					gtk_list_store_set(store,&iter,NOMHOTEL,nomhotel,ETOILE,etoile,PRIXSWE,prixswe,PRIXA1,prixa1,PRIXA2,prixa2,PRIXA3,prixa3,PRIXPER,prixper,-1);
				}
			fclose(f);
			gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
			g_object_unref (store);
		}

	}


}




hotel search(char f[100])
{
	FILE *fp;
	hotel h;
	fp=fopen("hotel.txt","r");
	while(fscanf(fp,"%s %s %s %s %s %s %s\n",h.nomhotel,h.etoile,h.prixswe,h.prixa1,h.prixa2,h.prixa3,h.prixper))
	{if (strcmp(h.nomhotel,f)==0) {fclose(fp);return h;}
		
	}
		fclose(fp);
		return h;
	/*int test=0;
	char *gg;
	hotel h;
	fp = fopen("hotel.txt","r+");
	while (!feof(fp))
	{
		test =0;
		fgets(gg,100,fp);
		for (int i = 0;i<100;i++)
		{
			if(gg[i] ==" ")
			{break;}			
			if (gg[i] != f[i]) 
			{
				test=1;
				break;
			}
		}
		if (test==0)
		{break;}
	}

	test = 1;
	for (int i=0;i<100;i++)
	{
		if (gg[i] == " ")
		{test+=1;}
		if (gg[i]=="\n")
		{break;}
		if (test=1)
		{strcat(h.nomhotel,gg[i]);}
		if (test=2)
		{strcat(h.etoile,gg[i]);}
		if (test=3)
		{strcat(h.prixswe,gg[i]);}
		if (test=4)
		{strcat(h.prixa1,gg[i]);}
		if (test=5)
		{strcat(h.prixa2,gg[i]);}
		if (test=6)
		{strcat(h.prixa3,gg[i]);}
		if (test=7)
		{strcat(h.prixper,gg[i]);}
	}
	fclose(fp);
	fp = fopen("info.txt","w+");
	fprintf(fp,"%s,%s,%s,%s,%s,%s,%s\n", 	h.nomhotel,h.etoile,h.prixswe,h.prixa1,h.prixa2,h.prixa3,h.prixper);
fclose(fp);
return h;*/
}







void info(char nbrper[100],char nbradu[100],char nbrswe[100],char nbra1[100],char nbra2[100],char nbra3[100],char datea[100],char datel[100],char id[100])
{
	FILE *fp;
	fp=fopen("info.txt","w+");
	fprintf(fp,"%s,%s,%s,%s,%s,%s,%s",nbrper,nbradu,nbrswe,nbra1,nbra2,nbra3,datea,datel,id);
	fprintf(fp,"%s","\n");
}








/*void search2(char f[100])
{
	FILE *fp;
	int test=0,status,res;
	char gg[100],ez[100];
	hotel h;
	fp = fopen("hotel.txt","r");
	while (!feof(fp))
	{
		test =0;
		fgets(gg,100,fp);
		for (int i = 0;i<100;i++)
		{
			if(strcmp(gg[i] ," ")==0)
			{break;}			
			if (strcmp(gg[i], f[i])!=0 )
			{
				test=1;
				break;
			}
		}
		if (test==0)
		{break;}
		if (feof(fp)){return 0;}
	}
	
	fclose(fp);	
	

	fp = fopen("hotel2.txt","a+");
	while(!feof(fp))
	{
		fgets(ez,100,fp);
		if (strcmp(gg,ez)!=0)
		{fprintf(fp,"%s%s",ez,"\n");}
	}

	fclose(fp);
	status = remove("hotel.txt");
	status = rename("hotel2.txt","hotel.txt");


	
	
	
}*/





void search2(char hjk[])
{
    hotel C;
  FILE* fichierIn=NULL;
  FILE* fichierOut=NULL;
fichierIn=fopen("hotel.txt", "r");
fichierOut = fopen("copie.txt", "w");
 if (fichierIn != NULL)
 {

while(!feof(fichierIn)){

      fscanf(fichierIn,"%s %s %s %s %s %s %s \n", C.nomhotel,C.etoile,C.prixswe,C.prixa1,C.prixa2,C.prixa3,C.prixper);
      if (strcmp(C.nomhotel,hjk)!=0)
      {fprintf(fichierOut,"%s %s %s %s %s %s %s \n", C.nomhotel,C.etoile,C.prixswe,C.prixa1,C.prixa2,C.prixa3,C.prixper);}
      }

    fclose(fichierIn);
    fclose(fichierOut);

    remove("hotel.txt");
    rename("copie.txt", "hotel.txt");
}}
































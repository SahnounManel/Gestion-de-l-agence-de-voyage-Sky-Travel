#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>




void afficher_employe(GtkWidget *treeview_employes);


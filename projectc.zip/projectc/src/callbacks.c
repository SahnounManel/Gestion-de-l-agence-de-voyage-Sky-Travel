#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//#include "itoa.h"
#include "treeview_employe.h"
#include "treeview_client.h"
//#include "tostring.h"
#include "split.h"
#include "controle_saisie.h"

#include "callbacks.h"
#include "interface.h"
#include "utilisateur.h"
#include "support.h"


void
on_button_seconnecter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *input2;
char id[100];
char mdp[100];
GtkWidget *AUTHENTIFICATION, *Espace_Administrateur, *Espace_Employe, *Espace_Client, *Login_error;

input1 = lookup_widget(objet, "entry_identifiant0") ;
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
input2 = lookup_widget(objet, "entry_motdepasse0") ;
strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(input2)));
if (login(id,mdp)==1)
{AUTHENTIFICATION=lookup_widget(objet,"AUTHENTIFICATION");
Espace_Administrateur=create_Espace_Administrateur();
gtk_widget_show(Espace_Administrateur);}
else if (login(id,mdp)==2)
{AUTHENTIFICATION=lookup_widget(objet,"AUTHENTIFICATION");
Espace_Employe=create_Espace_Employe();
gtk_widget_show(Espace_Employe);}
else if (login(id,mdp)==3)
{AUTHENTIFICATION=lookup_widget(objet,"AUTHENTIFICATION");
Espace_Client=create_Espace_Client();
gtk_widget_show(Espace_Client);}
else if (login(id,mdp)==0)
{AUTHENTIFICATION=lookup_widget(objet,"AUTHENTIFICATION");
Login_error=create_Login_error();
gtk_widget_show(Login_error);}
}


void
on_button_sinscrire_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *AUTHENTIFICATION, *Informations_clients;
AUTHENTIFICATION=lookup_widget(objet,"AUTHENTIFICATION");
Informations_clients=create_Informations_clients();
gtk_widget_show(Informations_clients);
}


void
on_button_gestionemployes_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_Administrateur, *Gestion_employes;
GtkWidget *treeview_employes;
Espace_Administrateur=lookup_widget(objet,"Espace_Administrateur");
Gestion_employes=lookup_widget(objet,"Gestion_employes");
Gestion_employes=create_Gestion_employes();
gtk_widget_show(Gestion_employes);
treeview_employes=lookup_widget(Gestion_employes,"treeview_employes");
afficher_employe(treeview_employes);
}


void
on_button_gestionclients_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_Administrateur, *Gestion_clients;
GtkWidget *treeview_clients;
Espace_Administrateur=lookup_widget(objet,"Espace_Administrateur");
Gestion_clients=lookup_widget(objet,"Gestion_clients");
Gestion_clients=create_Gestion_clients();
gtk_widget_show(Gestion_clients);
treeview_clients=lookup_widget(Gestion_clients,"treeview_clients");
afficher_client(treeview_clients);
}


void
on_button_ajouteremploye_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_employe, *Informations_employes;
Gestion_employe=lookup_widget(objet,"Gestion_employe");
Informations_employes=create_Informations_employes();
gtk_widget_show(Informations_employes);
}


void
on_button_ajouterclient_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_clients, *Informations_clients;
Gestion_clients=lookup_widget(objet,"Gestion_clients");
Informations_clients=create_Informations_clients();
gtk_widget_show(Informations_clients);
}


void
on_button_gestionclients1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_Employe, *Gestion_clients;
GtkWidget *treeview_clients;
Espace_Employe=lookup_widget(objet,"Espace_Employe");
Gestion_clients=lookup_widget(objet,"Gestion_clients");
Gestion_clients=create_Gestion_clients();
gtk_widget_show(Gestion_clients);
treeview_clients=lookup_widget(Gestion_clients,"treeview_clients");
afficher_client(treeview_clients);
}






void
on_button_confirmeremploye_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *input1, *input2, *input3, *input4, *input5, *input6, *output;
char jour[100],mois[100],annee[100],Date[100];
GtkWidget *combobox_jour1;
GtkWidget *combobox_mois1;
GtkWidget *combobox_annee1;
GtkWidget *combobox_employe;
GtkWidget *Informations_employes;
Employe E;

Informations_employes=lookup_widget(objet,"Informations_employes");
input1 = lookup_widget(objet, "entry_identifiant1") ;
strcpy(E.Identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
input2 = lookup_widget(objet, "entry_nom1") ;
strcpy(E.Nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3 = lookup_widget(objet, "entry_prenom1") ;
strcpy(E.Prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4 = lookup_widget(objet, "entry_email1") ;
strcpy(E.Email,gtk_entry_get_text(GTK_ENTRY(input4)));
input5 = lookup_widget(objet, "entry_telephone1") ;
strcpy(E.Telephone,gtk_entry_get_text(GTK_ENTRY(input5)));
input6 = lookup_widget(objet, "entry_motdepasse1") ;
strcpy(E.Motdepasse,gtk_entry_get_text(GTK_ENTRY(input6)));
combobox_jour1=lookup_widget(objet, "combobox_jour1");
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_jour1)));
combobox_mois1=lookup_widget(objet, "combobox_mois1");
strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_mois1)));
combobox_annee1=lookup_widget(objet, "combobox_annee1");
strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_annee1)));
/*Jour=lookup_widget(objet, "spinbutton_jour1");
Mois=lookup_widget(objet, "spinbutton_mois1");
Annee=lookup_widget(objet, "spinbutton_annee1");
jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
sprintf(sjour,"%d",jour);
sprintf(smois,"%d",mois);
sprintf(sannee,"%d",annee);*/
strcpy(Date,jour);
strcat(Date,"/");
strcat(Date,mois);
strcat(Date,"/");
strcat(Date,annee);
strcpy(E.Date_recrutement,Date);
combobox_employe=lookup_widget(objet, "combobox_employe");
if(strcmp("Administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_employe)))==0)
strcpy(E.Role,"administrateur");
else
strcpy(E.Role,"employe");
output= lookup_widget(objet, "label_employe");
if (chercher_employe(E.Identifiant)==1)
{
      gtk_label_set_text(GTK_LABEL(output), "Identifiant déjà utilisé !");
}
else 
{
	if ((digital(E.Identifiant)==0)||(controle_saisie_numero(E.Telephone)==0))
	{
	gtk_label_set_text(GTK_LABEL(output), "veuillez verifier votre saisie !");
	}
	else{
ajouter_employe(E);
gtk_label_set_text(GTK_LABEL(output),"employe ajouté avec succès");}
}
}

void
on_button_confirmerclient_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget  *input1, *input2, *input3, *input4, *input5, *input6, *output;
char jour[100],mois[100],annee[100],Date[100];
GtkWidget *combobox_jour2, *combobox_mois2, *combobox_annee2;
GtkWidget *Informations_clients;
Client C;

Informations_clients=lookup_widget(objet,"Informations_clients");
input1 = lookup_widget(objet, "entry_identifiant2") ;
strcpy(C.Identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
input2 = lookup_widget(objet, "entry_nom2") ;
strcpy(C.Nom,gtk_entry_get_text(GTK_ENTRY(input2)));
input3 = lookup_widget(objet, "entry_prenom2") ;
strcpy(C.Prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
input4 = lookup_widget(objet, "entry_email2") ;
strcpy(C.Email,gtk_entry_get_text(GTK_ENTRY(input4)));
input5 = lookup_widget(objet, "entry_telephone2") ;
strcpy(C.Telephone,gtk_entry_get_text(GTK_ENTRY(input5)));
input6 = lookup_widget(objet, "entry_motdepasse2") ;
strcpy(C.Motdepasse,gtk_entry_get_text(GTK_ENTRY(input6)));
combobox_jour2=lookup_widget(objet, "combobox_jour2");
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_jour2)));
combobox_mois2=lookup_widget(objet, "combobox_mois2");
strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_mois2)));
combobox_annee2=lookup_widget(objet, "combobox_annee2");
strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_annee2)));
/*Jour=lookup_widget(objet, "spinbutton_jour2");
Mois=lookup_widget(objet, "spinbutton_mois2");
Annee=lookup_widget(objet, "spinbutton_annee2");
jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
sprintf(sjour,"%d",jour);
sprintf(smois,"%d",mois);
sprintf(sannee,"%d",annee);
itoa(jour,sjour);
itoa(mois,smois);
itoa(annee,sannee);*/
strcpy(Date,jour);
strcat(Date,"/");
strcat(Date,mois);
strcat(Date,"/");
strcat(Date,annee);
strcpy(C.Date_naissance,Date);
output= lookup_widget(objet, "label_client");
if (chercher_client(C.Identifiant)==1)
{
      gtk_label_set_text(GTK_LABEL(output), "Identifiant déjà utilisé !");
}
else 
{
	if ((digital(C.Identifiant)==0)||(controle_saisie_numero(C.Telephone)==0))
	{
	gtk_label_set_text(GTK_LABEL(output), "veuillez verifier votre saisie !");
	}
	else{
ajouter_client(C);
gtk_label_set_text(GTK_LABEL(output),"client ajouté avec succès");}
}
}



void
on_button_modifierclient_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_clients, *Modifier_client;
Gestion_clients=lookup_widget(objet,"Gestion_clients");
Modifier_client=create_Modifier_client();
gtk_widget_show(Modifier_client);
}


void
on_button_modifieremploye_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_employes, *Modifier_employe;
Gestion_employes=lookup_widget(objet,"Gestion_employes");
Modifier_employe=create_Modifier_employe();
gtk_widget_show(Modifier_employe);
}


void
on_button_quitter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button_actualiseremploye_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_employes, *treeview_employes;
Gestion_employes=lookup_widget(objet,"Gestion_employes");
gtk_widget_hide(Gestion_employes);

Gestion_employes = create_Gestion_employes ();
gtk_widget_show (Gestion_employes);

treeview_employes=lookup_widget(Gestion_employes,"treeview_employes");
afficher_employe(treeview_employes);
}


void
on_button_actualiserclient_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_clients, *treeview_clients;
Gestion_clients=lookup_widget(objet,"Gestion_clients");
gtk_widget_hide(Gestion_clients);

Gestion_clients = create_Gestion_clients ();
gtk_widget_show (Gestion_clients);

treeview_clients=lookup_widget(Gestion_clients,"treeview_clients");
afficher_client(treeview_clients);
}


void
on_button_trouverclient_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output, *input1, *input2, *input3, *input4, *input5, *combobox_jour4, *combobox_mois4, *combobox_annee4;
char id[100], jour[100], mois[100], annee[100];
int n;
Client C;
FILE* f=NULL;
char ** tab;

input = lookup_widget(objet, "entry_identifiant4");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_trouverclient");

input1 = lookup_widget(objet,"entry_nom4");
input2 = lookup_widget(objet,"entry_prenom4");
input3 = lookup_widget(objet,"entry_email4");
input4 = lookup_widget(objet,"entry_telephone4");
input5 = lookup_widget(objet,"entry_motdepasse4");
combobox_jour4=lookup_widget(objet, "combobox_jour4");
combobox_mois4=lookup_widget(objet, "combobox_mois4");
combobox_annee4=lookup_widget(objet, "combobox_annee4");
/*Jour = lookup_widget(objet, "spinbutton_jour4");
Mois=lookup_widget(objet, "spinbutton_mois2");
Annee=lookup_widget(objet, "spinbutton_annee2");*/



n=chercher_client(id);
if (n==0)
{
    gtk_label_set_text(GTK_LABEL(output), "Aucun client n'est inscrit avec cet identifiant, veuillez réessayer");
}
else {
	f = fopen("clients.txt", "r");
	while((fscanf(f,"%s %s %s %s %s %s %s \n", 			C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse)!= EOF))
	{ if ((strcmp(C.Identifiant,id)==0))
	{fclose(f);
	 break;}}
	fclose(f);	
	
	gtk_label_set_text(GTK_LABEL(output), "Identifiant existant");

	gtk_entry_set_text(GTK_ENTRY(input1), C.Nom);
	gtk_entry_set_text(GTK_ENTRY(input2), C.Prenom);
	gtk_entry_set_text(GTK_ENTRY(input3), C.Email);
	gtk_entry_set_text(GTK_ENTRY(input4), C.Telephone);
	gtk_entry_set_text(GTK_ENTRY(input5), C.Motdepasse);

	tab=split(C.Date_naissance,"/",0);
	strcpy(jour,tab[0]);
	strcpy(mois,tab[1]);
	strcpy(annee,tab[2]);


	gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_jour4),atoi(jour));
	gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_mois4),atoi(mois));
	gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_annee4),atoi(annee));
	
	
	/*ijour=toString(jour);
	imois=toString(mois);
	iannee=toString(annee);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (Jour),ijour);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (Mois),imois);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (Annee),iannee);*/
}
}

void
on_button_modifierclient1_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output, *input1, *input2, *input3, *input4, *input5, *combobox_jour4, *combobox_mois4, *combobox_annee4;
char id[100], jour[100], mois[100], annee[100], Date[100];
int n;
Client C;
FILE* f=NULL;
char ** tab;

input = lookup_widget(objet, "entry_identifiant4");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_client4");

input1 = lookup_widget(objet,"entry_nom4");
input2 = lookup_widget(objet,"entry_prenom4");
input3 = lookup_widget(objet,"entry_email4");
input4 = lookup_widget(objet,"entry_telephone4");
input5 = lookup_widget(objet,"entry_motdepasse4");
combobox_jour4=lookup_widget(objet, "combobox_jour4");
combobox_mois4=lookup_widget(objet, "combobox_mois4");
combobox_annee4=lookup_widget(objet, "combobox_annee4");



n=chercher_client(id);
if (n==0)
{
    gtk_label_set_text(GTK_LABEL(output), "aucune chose à modifier");
}
else {	
	
	strcpy(C.Identifiant,gtk_entry_get_text(GTK_ENTRY(input)));
	strcpy(C.Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(C.Prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(C.Email,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(C.Telephone,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(C.Motdepasse,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_jour4)));
	strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_mois4)));
	strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_annee4)));

	strcpy(Date,jour);
	strcat(Date,"/");
	strcat(Date,mois);
	strcat(Date,"/");
	strcat(Date,annee);
	strcpy(C.Date_naissance,Date);
	
	
	gtk_label_set_text(GTK_LABEL(output), "Champs modifier avec succès");
	modifier_client(C);
}
}


void
on_button_trouver_employe_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output, *input1, *input2, *input3, *input4, *input5, *combobox_jour3, *combobox_mois3, *combobox_annee3, *combobox_employe1;
char id[100], jour[100], mois[100], annee[100];
int n;
Employe E;
FILE* f=NULL;
char ** tab;

input = lookup_widget(objet, "entry_identifiant3");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_trouveremploye");

input1 = lookup_widget(objet,"entry_nom3");
input2 = lookup_widget(objet,"entry_prenom3");
input3 = lookup_widget(objet,"entry_email3");
input4 = lookup_widget(objet,"entry_telephone3");
input5 = lookup_widget(objet,"entry_motdepasse3");
combobox_jour3=lookup_widget(objet, "combobox_jour3");
combobox_mois3=lookup_widget(objet, "combobox_mois3");
combobox_annee3=lookup_widget(objet, "combobox_annee3");
combobox_employe1=lookup_widget(objet, "combobox_employe1");



n=chercher_employe(id);
if (n==0)
{
    gtk_label_set_text(GTK_LABEL(output), "Aucun employe n'est inscrit avec cet identifiant, veuillez réessayer");
}
else {
	f = fopen("employes.txt", "r");
	while((fscanf(f,"%s %s %s %s %s %s %s %s \n", 			E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse)!= EOF))
	{ if ((strcmp(E.Identifiant,id)==0))
	{fclose(f);
	 break;}}
	fclose(f);	
	
	gtk_label_set_text(GTK_LABEL(output), "Identifiant existant");

	gtk_entry_set_text(GTK_ENTRY(input1), E.Nom);
	gtk_entry_set_text(GTK_ENTRY(input2), E.Prenom);
	gtk_entry_set_text(GTK_ENTRY(input3), E.Email);
	gtk_entry_set_text(GTK_ENTRY(input4), E.Telephone);
	gtk_entry_set_text(GTK_ENTRY(input5), E.Motdepasse);

	tab=split(E.Date_recrutement,"/",0);
	strcpy(jour,tab[0]);
	strcpy(mois,tab[1]);
	strcpy(annee,tab[2]);


	gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_jour3),atoi(jour));
	gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_mois3),atoi(mois));
	gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_annee3),atoi(annee));
	gtk_combo_box_append_text(GTK_COMBO_BOX(combobox_employe1),E.Role);
	
}
}


void
on_button_modifieremploye1_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output, *input1, *input2, *input3, *input4, *input5, *combobox_jour3, *combobox_mois3, *combobox_annee3, *combobox_employe1;
char id[100], jour[100], mois[100], annee[100], Date[100];
int n;
Employe E;
FILE* f=NULL;
char ** tab;

input = lookup_widget(objet, "entry_identifiant3");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_employe3");

input1 = lookup_widget(objet,"entry_nom3");
input2 = lookup_widget(objet,"entry_prenom3");
input3 = lookup_widget(objet,"entry_email3");
input4 = lookup_widget(objet,"entry_telephone3");
input5 = lookup_widget(objet,"entry_motdepasse3");
combobox_jour3=lookup_widget(objet, "combobox_jour3");
combobox_mois3=lookup_widget(objet, "combobox_mois3");
combobox_annee3=lookup_widget(objet, "combobox_annee3");
combobox_employe1=lookup_widget(objet, "combobox_employe1");



n=chercher_employe(id);
if (n==0)
{
    gtk_label_set_text(GTK_LABEL(output), "aucune chose à modifier");
}
else {	
	
	strcpy(E.Identifiant,gtk_entry_get_text(GTK_ENTRY(input)));
	strcpy(E.Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(E.Prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(E.Email,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(E.Telephone,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(E.Motdepasse,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_jour3)));
	strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_mois3)));
	strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_annee3)));

	strcpy(Date,jour);
	strcat(Date,"/");
	strcat(Date,mois);
	strcat(Date,"/");
	strcat(Date,annee);
	strcpy(E.Date_recrutement,Date);
	
	if(strcmp("Administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_employe1)))==0)
		strcpy(E.Role,"administrateur");
	else
		strcpy(E.Role,"employe");
	
	gtk_label_set_text(GTK_LABEL(output), "Champs modifier avec succès");
	modifier_employe(E);
}
}


void
on_button_supprimeremploye1_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output;
GtkWidget *entry_identifiantsup1;
GtkWidget *label_supprimeremploye;
int n;
char id[100];
input = lookup_widget(objet, "entry_identifiantsup1") ;
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_supprimeremploye");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
  n=chercher_employe(id);
  if (n==0)
  {
    gtk_label_set_text(GTK_LABEL(output), "Nothing to be deleted");
  }
  else
  {
    gtk_label_set_text(GTK_LABEL(output), "Champs supprimer avec succès");
    supprimer_employe(id);
}
}

void
on_button_supprimerclient1_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output;
GtkWidget *entry_identifiantsup2;
GtkWidget *label_supprimerclient;
int n;
char id[100];
input = lookup_widget(objet, "entry_identifiantsup2") ;
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_supprimerclient");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
  n=chercher_client(id);
  if (n==0)
  {
    gtk_label_set_text(GTK_LABEL(output), "Nothing to be deleted");
  }
  else
  {
    gtk_label_set_text(GTK_LABEL(output), "Champs supprimer avec succès");
    supprimer_client(id);
}
}




void
on_button_supprimeremploye_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_employes, *Supprimer_employe;
Gestion_employes=lookup_widget(objet,"Gestion_employes");
Supprimer_employe=create_Supprimer_employe();
gtk_widget_show(Supprimer_employe);
}
void
on_button_supprimerclient_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_clients, *Supprimer_client;
Gestion_clients=lookup_widget(objet,"Gestion_clients");
Supprimer_client=create_Supprimer_client();
gtk_widget_show(Supprimer_client);
}


void
on_button_informationspersonnelles1_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_Employe, *Informations_personnellesemploye;

Espace_Employe=lookup_widget(objet,"Espace_Employe");
Informations_personnellesemploye=lookup_widget(objet,"Informations_personnellesemploye");
Informations_personnellesemploye=create_Informations_personnellesemploye();
gtk_widget_show(Informations_personnellesemploye);


}


void
on_button_informationspersonnelles2_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Espace_Client, *Informations_personnellesclient;

Espace_Client=lookup_widget(objet,"Espace_Client");
Informations_personnellesclient=lookup_widget(objet,"Informations_personnellesclient");
Informations_personnellesclient=create_Informations_personnellesclient();
gtk_widget_show(Informations_personnellesclient);
	

}


void
on_button_supprimercompte_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE* f=NULL;
Client C;
GtkWidget *AUTHENTIFICATION, *Espace_Client;
f=fopen("login2.txt", "r");
while(fscanf(f,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse)!=EOF);
supprimer_client(C.Identifiant);
fclose(f);

Espace_Client=lookup_widget(objet,"Espace_Client");
AUTHENTIFICATION=create_AUTHENTIFICATION();
gtk_widget_show(AUTHENTIFICATION);

}


void
on_button_infpersoemp_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output, *input1, *input2, *input3, *input4, *input5, *combobox_jour5, *combobox_mois5, *combobox_annee5, *combobox_employe5;
char id[100], jour[100], mois[100], annee[100], Date[100];
int n;
Employe E;
FILE* f=NULL;
char ** tab;

input = lookup_widget(objet, "entry_identifiant5");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_employe5");

input1 = lookup_widget(objet,"entry_nom5");
input2 = lookup_widget(objet,"entry_prenom5");
input3 = lookup_widget(objet,"entry_email5");
input4 = lookup_widget(objet,"entry_telephone5");
input5 = lookup_widget(objet,"entry_motdepasse5");
combobox_jour5=lookup_widget(objet, "combobox_jour5");
combobox_mois5=lookup_widget(objet, "combobox_mois5");
combobox_annee5=lookup_widget(objet, "combobox_annee5");
combobox_employe5=lookup_widget(objet, "combobox_employe5");



n=chercher_employe(id);
if (n==0)
{
    gtk_label_set_text(GTK_LABEL(output), "aucune chose à modifier");
}
else {	
	
	strcpy(E.Identifiant,gtk_entry_get_text(GTK_ENTRY(input)));
	strcpy(E.Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(E.Prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(E.Email,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(E.Telephone,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(E.Motdepasse,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_jour5)));
	strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_mois5)));
	strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_annee5)));

	strcpy(Date,jour);
	strcat(Date,"/");
	strcat(Date,mois);
	strcat(Date,"/");
	strcat(Date,annee);
	strcpy(E.Date_recrutement,Date);
	
	if(strcmp("Administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_employe5)))==0)
		strcpy(E.Role,"administrateur");
	else
		strcpy(E.Role,"employe");
	
	gtk_label_set_text(GTK_LABEL(output), "Champs modifier avec succès");
	modifier_employe(E);
}
}


void
on_button_infpersoclient_clicked       (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *output, *input1, *input2, *input3, *input4, *input5, *combobox_jour6, *combobox_mois6, *combobox_annee6;
char id[100], jour[100], mois[100], annee[100], Date[100];
int n;
Client C;
FILE* f=NULL;
char ** tab;

input = lookup_widget(objet, "entry_identifiant6");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
output= lookup_widget(objet, "label_client6");

input1 = lookup_widget(objet,"entry_nom6");
input2 = lookup_widget(objet,"entry_prenom6");
input3 = lookup_widget(objet,"entry_email6");
input4 = lookup_widget(objet,"entry_telephone6");
input5 = lookup_widget(objet,"entry_motdepasse6");
combobox_jour6=lookup_widget(objet, "combobox_jour6");
combobox_mois6=lookup_widget(objet, "combobox_mois6");
combobox_annee6=lookup_widget(objet, "combobox_annee6");



n=chercher_client(id);
if (n==0)
{
    gtk_label_set_text(GTK_LABEL(output), "aucune chose à modifier");
}
else {	
	
	strcpy(C.Identifiant,gtk_entry_get_text(GTK_ENTRY(input)));
	strcpy(C.Nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(C.Prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(C.Email,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(C.Telephone,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(C.Motdepasse,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_jour6)));
	strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_mois6)));
	strcpy(annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_annee6)));

	strcpy(Date,jour);
	strcat(Date,"/");
	strcat(Date,mois);
	strcat(Date,"/");
	strcat(Date,annee);
	strcpy(C.Date_naissance,Date);
	
	
	gtk_label_set_text(GTK_LABEL(output), "Champs modifier avec succès");
	modifier_client(C);
}
}


void
on_button_afficherinfemp_clicked       (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *input1, *input2, *input3, *input4, *input5, *combobox_jour5, *combobox_mois5, *combobox_annee5, *combobox_employe5;
char jour[100], mois[100], annee[100];
Employe E;
FILE* f=NULL;
char ** tab;
f=fopen("login1.txt", "r");
while(fscanf(f,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse)!=EOF);
fclose(f);

input = lookup_widget(objet, "entry_identifiant5");
input1 = lookup_widget(objet,"entry_nom5");
input2 = lookup_widget(objet,"entry_prenom5");
input3 = lookup_widget(objet,"entry_email5");
input4 = lookup_widget(objet,"entry_telephone5");
input5 = lookup_widget(objet,"entry_motdepasse5");
combobox_jour5=lookup_widget(objet, "combobox_jour5");
combobox_mois5=lookup_widget(objet, "combobox_mois5");
combobox_annee5=lookup_widget(objet, "combobox_annee5");
combobox_employe5=lookup_widget(objet, "combobox_employe5");

gtk_entry_set_text(GTK_ENTRY(input), E.Identifiant);
gtk_entry_set_text(GTK_ENTRY(input1), E.Nom);
gtk_entry_set_text(GTK_ENTRY(input2), E.Prenom);
gtk_entry_set_text(GTK_ENTRY(input3), E.Email);
gtk_entry_set_text(GTK_ENTRY(input4), E.Telephone);
gtk_entry_set_text(GTK_ENTRY(input5), E.Motdepasse);

tab=split(E.Date_recrutement,"/",0);
strcpy(jour,tab[0]);
strcpy(mois,tab[1]);
strcpy(annee,tab[2]);


gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_jour5),atoi(jour));
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_mois5),atoi(mois));
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_annee5),atoi(annee));
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox_employe5),E.Role);
}


void
on_button_afficherinfclient_clicked    (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *input, *input1, *input2, *input3, *input4, *input5, *combobox_jour6, *combobox_mois6, *combobox_annee6;
char jour[100], mois[100], annee[100];
Client C;
FILE* f=NULL;
char ** tab;

f=fopen("login2.txt", "r");
while(!feof(f)){

      fscanf(f,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);}
fclose(f);

input = lookup_widget(objet, "entry_identifiant6");
input1 = lookup_widget(objet,"entry_nom6");
input2 = lookup_widget(objet,"entry_prenom6");
input3 = lookup_widget(objet,"entry_email6");
input4 = lookup_widget(objet,"entry_telephone6");
input5 = lookup_widget(objet,"entry_motdepasse6");
combobox_jour6=lookup_widget(objet, "combobox_jour6");
combobox_mois6=lookup_widget(objet, "combobox_mois6");
combobox_annee6=lookup_widget(objet, "combobox_annee6");

gtk_entry_set_text(GTK_ENTRY(input), C.Identifiant);
gtk_entry_set_text(GTK_ENTRY(input1), C.Nom);
gtk_entry_set_text(GTK_ENTRY(input2), C.Prenom);
gtk_entry_set_text(GTK_ENTRY(input3), C.Email);
gtk_entry_set_text(GTK_ENTRY(input4), C.Telephone);
gtk_entry_set_text(GTK_ENTRY(input5), C.Motdepasse);

tab=split(C.Date_naissance,"/",0);
strcpy(jour,tab[0]);
strcpy(mois,tab[1]);
strcpy(annee,tab[2]);


gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_jour6),atoi(jour));
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_mois6),atoi(mois));
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_annee6),atoi(annee));
	

}


void
on_button_gestiondesreclamations_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestionhebergement_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondesexcurtions_clicked (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondelocation_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondepaiement_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondesvols_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestionhebergement1_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondesvols1_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondepaiement1_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondelocation1_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_gestiondesexcursions1_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_reclamations_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_locationdesvoitures_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_reservationdesexcursion_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_reservationdevols_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_paiement_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_reservationhebergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


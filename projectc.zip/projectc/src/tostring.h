#include <stdio.h>
long toString(char a[]);

#include <gtk/gtk.h>



void
on_button_seconnecter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sinscrire_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gestionemployes_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gestionclients_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouteremploye_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouterclient_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gestionclients1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button_confirmeremploye_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_confirmerclient_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button_modifierclient_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifieremploye_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_quitter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_actualiseremploye_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_actualiserclient_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_trouverclient_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifierclient1_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_trouver_employe_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifieremploye1_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimeremploye1_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimerclient1_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifieremploye_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimeremploye_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifierclient_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimerclient_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_informationspersonnelles1_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_informationspersonnelles2_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimercompte_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button_infpersoemp_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_infpersoclient_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afficherinfemp_clicked       (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button_afficherinfclient_clicked    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button_gestiondesreclamations_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestionhebergement_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondesexcurtions_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondelocation_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondepaiement_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondesvols_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestionhebergement1_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondesvols1_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondepaiement1_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondelocation1_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_gestiondesexcursions1_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_reclamations_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_locationdesvoitures_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_reservationdesexcursion_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_reservationdevols_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_paiement_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_reservationhebergement_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

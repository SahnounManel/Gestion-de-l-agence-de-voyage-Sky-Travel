#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "utilisateur.h"




int login(char id[],char mdp[])
{
FILE* f1=NULL;
FILE* f2=NULL;
FILE* f4=NULL;
FILE* f5=NULL;
Employe E;
Client C;
f1 = fopen("employes.txt", "r");
while((fscanf(f1,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse)!= EOF))
{ if ((strcmp(E.Identifiant,id)==0) && (strcmp(E.Motdepasse,mdp)==0) && (strcmp(E.Role,"administrateur")==0))
	{fclose(f1);
	 return(1);
	 break;}
  else if ((strcmp(E.Identifiant,id)==0) && (strcmp(E.Motdepasse,mdp)==0) && (strcmp(E.Role,"employe")==0))
	{f4=fopen("login1.txt", "a+");
	 fprintf(f4,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse);
	 fclose(f4);
	 fclose(f1);
	 return(2);
	 break;}}
fclose(f1);

f2 = fopen("clients.txt", "r");
while((fscanf(f2,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse)!= EOF))
{ if ((strcmp(C.Identifiant,id)==0) && (strcmp(C.Motdepasse,mdp)==0))
	{f5=fopen("login2.txt", "a+");
	 fprintf(f5,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);
	 fclose(f5);
	 fclose(f2);
	 return(3);
	 break;}}
fclose(f2);

return(0);}


void ajouter_employe(Employe E)
{
FILE* f=NULL;
f=fopen("employes.txt", "a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse);
fclose(f);}
}


void ajouter_client(Client C)
{
FILE* f=NULL;
f=fopen("clients.txt", "a+");
if (f!=NULL)
{fprintf(f,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);
fclose(f);}
}


int chercher_employe(char id[])
{

 Employe E;
 int compare=1;

FILE* fichier=NULL;
fichier=fopen("employes.txt","r");

 if (fichier != NULL)
    {


while((!feof(fichier)) && (compare != 0)){


       fscanf(fichier,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse);
       compare=strcmp(E.Identifiant,id);

}

if (compare == 0)

      {
          return 1;
      }
      else
      {
         return 0;
      }

fclose(fichier);
    }

    else {

    return 2;
    }

}


int chercher_client(char id[])
{

 Client C;
 int compare=1;

FILE* fichier=NULL;
fichier=fopen("clients.txt","r");

 if (fichier != NULL)
    {


while((!feof(fichier)) && (compare != 0)){


       fscanf(fichier,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);
       compare=strcmp(C.Identifiant,id);

}

if (compare == 0)

      {
          return 1;
      }
      else
      {
         return 0;
      }

fclose(fichier);
    }

    else {

    return 2;
    }

}


void supprimer_employe(char id[])
{
    Employe E;
  FILE* fichierIn=NULL;
  FILE* fichierOut=NULL;
fichierIn=fopen("employes.txt", "r");
fichierOut = fopen("copieemployes.txt", "w");
 if (fichierIn != NULL)
 {

while(!feof(fichierIn)){

      fscanf(fichierIn,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse);
      if (strcmp(E.Identifiant,id)!=0)
      {fprintf(fichierOut,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse);}
      }

    fclose(fichierIn);
    fclose(fichierOut);

    remove("employes.txt");
    rename("copieemployes.txt", "employes.txt");
}}


void supprimer_client(char id[])
{
    Client C;
  FILE* fichierIn=NULL;
  FILE* fichierOut=NULL;
fichierIn=fopen("clients.txt", "r");
fichierOut = fopen("copieclients.txt", "w");
 if (fichierIn != NULL)
 {

while(!feof(fichierIn)){

      fscanf(fichierIn,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);
      if (strcmp(C.Identifiant,id)!=0)
      {fprintf(fichierOut,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);}
      }

    fclose(fichierIn);
    fclose(fichierOut);

    remove("clients.txt");
    rename("copieclients.txt", "clients.txt");
}}


void modifier_employe(Employe E1)
{
    Employe E;
  FILE* fichierIn=NULL;
  FILE* fichierOut=NULL;
fichierIn=fopen("employes.txt", "r");
fichierOut = fopen("copieemployes.txt", "w");
 if (fichierIn != NULL)
 {

while(!feof(fichierIn)){

      fscanf(fichierIn,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse);
      if (strcmp(E.Identifiant,E1.Identifiant)!=0)
      {fprintf(fichierOut,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E.Nom,E.Prenom,E.Date_recrutement,E.Email,E.Telephone,E.Role,E.Motdepasse);}

      else if (strcmp(E.Identifiant,E1.Identifiant)==0)
{fprintf(fichierOut,"%s %s %s %s %s %s %s %s \n", E.Identifiant,E1.Nom,E1.Prenom,E1.Date_recrutement,E1.Email,E1.Telephone,E1.Role,E1.Motdepasse);}}
    fclose(fichierIn);
    fclose(fichierOut);
}
    remove("employes.txt");
    rename("copieemployes.txt", "employes.txt");
}


void modifier_client(Client C1)
{
    Client C;
  FILE* fichierIn=NULL;
  FILE* fichierOut=NULL;
fichierIn=fopen("clients.txt", "r");
fichierOut = fopen("copieclients.txt", "w");
 if (fichierIn != NULL)
 {

while(!feof(fichierIn)){

      fscanf(fichierIn,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);
      if (strcmp(C.Identifiant,C1.Identifiant)!=0)
      {fprintf(fichierOut,"%s %s %s %s %s %s %s \n", C.Identifiant,C.Nom,C.Prenom,C.Date_naissance,C.Email,C.Telephone,C.Motdepasse);}

      else if (strcmp(C.Identifiant,C1.Identifiant)==0)
{fprintf(fichierOut,"%s %s %s %s %s %s %s \n", C.Identifiant,C1.Nom,C1.Prenom,C1.Date_naissance,C1.Email,C1.Telephone,C1.Motdepasse);}}
}
    fclose(fichierIn);
    fclose(fichierOut);

    remove("clients.txt");
    rename("copieclients.txt", "clients.txt");
}


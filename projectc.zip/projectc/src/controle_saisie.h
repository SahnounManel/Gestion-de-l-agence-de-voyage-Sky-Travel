#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>



int controle_saisie_numero(char x[15]);
int digital(char x[15]);

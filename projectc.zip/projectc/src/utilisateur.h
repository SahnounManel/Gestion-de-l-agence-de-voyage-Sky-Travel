typedef struct
{ char Identifiant[100];
  char Nom[100];
  char Prenom[100];
  char Date_recrutement[100];
  char Email[100];
  char Telephone[100];
  char Role[100];
  char Motdepasse[100];
}Employe;


typedef struct
{ char Identifiant[100];
  char Nom[100];
  char Prenom[100];
  char Date_naissance[100];
  char Email[100];
  char Telephone[100];
  char Motdepasse[100];
}Client;


int login(char id[],char mdp[]);

void ajouter_employe(Employe E);

void ajouter_client(Client C);

int chercher_employe(char id[]);

int chercher_client(char id[]);

void modifier_employe(Employe E1);

void modifier_client(Client C1);

void supprimer_employe(char id[]);

void supprimer_client(char id[]);






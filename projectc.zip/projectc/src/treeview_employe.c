#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include "utilisateur.h"
#include "treeview_employe.h"



enum 
{	IDENTIFIANT,
	NOM,
	PRENOM,
	DATE_RECRUTEMENT,
	EMAIL,
	TELEPHONE,
	ROLE,
	MOTDEPASSE,
	COLUMNS
};



void afficher_employe(GtkWidget *treeview_employes)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char Identifiant[100];
char Nom[100];
char Prenom[100];
char Date_recrutement[100];
char Email[100];
char Telephone[100];
char Role[100];
char Motdepasse[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(treeview_employes);
if (store==NULL)
{renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Identifiant",renderer, "text",IDENTIFIANT,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Prenom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Date_recrutement",renderer, "text",DATE_RECRUTEMENT,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Email",renderer, "text",EMAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Telephone",renderer, "text",TELEPHONE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Role",renderer, "text",ROLE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Motdepasse",renderer, "text",MOTDEPASSE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview_employes),column);
}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("employes.txt","r");
if(f==NULL)
{return;}
else
{f=fopen("employes.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s %s %s \n", Identifiant,Nom,Prenom,Date_recrutement,Email,Telephone,Role,Motdepasse)!=EOF)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,IDENTIFIANT,Identifiant,NOM,Nom,PRENOM,Prenom,DATE_RECRUTEMENT,Date_recrutement,EMAIL,Email,TELEPHONE,Telephone,ROLE,Role,MOTDEPASSE,Motdepasse,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(treeview_employes), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
}

